package com.slashmanx.chasetheace;

public final class R
{
  public static final class anim
  {
    public static final int slideleft = 2130968576;
    public static final int slideright = 2130968577;
  }

  public static final class attr
  {
  }

  public static final class dimen
  {
    public static final int font_size = 2131099649;
    public static final int smxy_gap = 2131099648;
  }

  public static final class drawable
  {
    public static final int ic_launcher = 2130837504;
  }

  public static final class id
  {
    public static final int FrameLayout1 = 2131361792;
    public static final int cardImage = 2131361799;
    public static final int connect_phones = 2131361796;
    public static final int connectionInfoLayout = 2131361793;
    public static final int dealButton = 2131361802;
    public static final int gameInfoLayout = 2131361797;
    public static final int msgText = 2131361801;
    public static final int newGameButton = 2131361803;
    public static final int overlayLayout = 2131361800;
    public static final int player_name = 2131361794;
    public static final int server_ip = 2131361795;
    public static final int tableRow4 = 2131361798;
  }

  public static final class integer
  {
    public static final int One = 2131165186;
    public static final int Three = 2131165185;
    public static final int Two = 2131165184;
    public static final int Zero = 2131165187;
  }

  public static final class layout
  {
    public static final int client = 2130903040;
  }

  public static final class raw
  {
    public static final int ah = 2131034112;
  }

  public static final class string
  {
    public static final int app_name = 2131230720;
  }

  public static final class style
  {
    public static final int AppBaseTheme = 2131296256;
    public static final int AppTheme = 2131296257;
    public static final int LoginFormContainer = 2131296258;
  }
}

/* Location:           /Users/emartin/Downloads/CTA/classes-dex2jar.jar
 * Qualified Name:     com.slashmanx.chasetheace.R
 * JD-Core Version:    0.6.0
 */