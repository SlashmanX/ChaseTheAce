package com.nineoldandroids.util;

public class NoSuchPropertyException extends RuntimeException
{
  public NoSuchPropertyException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /Users/emartin/Downloads/CTA/classes-dex2jar.jar
 * Qualified Name:     com.nineoldandroids.util.NoSuchPropertyException
 * JD-Core Version:    0.6.0
 */